//
const express = require('express');
const app = express();

const HOST = 'localhost';
const PORT = 3000;

const students = [
    {
      id: 1,
      last: "Last1",
      first: "First1",
    },
    {
      id: 2,
      last: "Last2",
      first: "First2",
    },
    {
      id: 3,
      last: "Last3",
      first: "First3",
    }
  ];

//CIT ruote
app.get('/cit', (req, res) => {
let data = {info: 'JSON response'};
res.status(200).type('application/json; charset=utf-8');
res.send(data);
});

app.get('/cit/student', (req, res) => {
    let data = {info: 'JSON response'};
    res.status(200).type('application/json; charset=utf-8');
    res.send(students);
    });

    app.get('/cit/student/:id', (req, res) => {
        const id = parseInt(req.params.id, 10);
        const student = students.find(s => s.id === id);
      
        if (student) {
          res.status(200).type('application/json; charset=utf-8').send(student);
        } else {
          res.status(404).type('application/json; charset=utf-8').send({ error: 'Not found' });
        }
      });
//Handle 404 for all other routes

app.use((req, res) => {
res.status(404).send('404 Not Found');
});

//start server
app.listen(PORT, HOST, () => {
console.log(`Server running at http://${HOST}:${PORT}`);
});